package template;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Test;
import org.mockito.Mockito;

import servlets.HelloServlet;

public class TestHelloServlet extends Mockito {

	@Test
	public void servlet_should_not_calculate_the_credit_if_kwotaKredyt_is_null() throws IOException {

		HttpServletRequest request = mock(HttpServletRequest.class);
		HttpServletResponse response = mock(HttpServletResponse.class);
		PrintWriter writer = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(writer);
		HelloServlet servlet = new HelloServlet();

		when(request.getParameter("rodzajRatKredyt")).thenReturn("malejace");
		when(request.getParameter("liczbaRatKredyt")).thenReturn("2");
		when(request.getParameter("kwotaKredyt")).thenReturn("");
		when(request.getParameter("oprocRokKredyt")).thenReturn("3");
		when(request.getParameter("oplataStalaKredyt")).thenReturn("10");
		servlet.doPost(request, response);
		verify(response).sendRedirect("/");
	}

	@Test
	public void servlet_should_not_calculate_the_credit_if_liczbaRatKredyt_is_null() throws IOException {

		HttpServletRequest request = mock(HttpServletRequest.class);
		HttpServletResponse response = mock(HttpServletResponse.class);
		PrintWriter writer = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(writer);
		HelloServlet servlet = new HelloServlet();

		when(request.getParameter("rodzajRatKredyt")).thenReturn("malejace");
		when(request.getParameter("liczbaRatKredyt")).thenReturn("0");
		when(request.getParameter("kwotaKredyt")).thenReturn("");
		when(request.getParameter("oprocRokKredyt")).thenReturn("3");
		when(request.getParameter("oplataStalaKredyt")).thenReturn("10");
		servlet.doPost(request, response);
		verify(response).sendRedirect("/");
	}

	@Test
	public void servlet_should_not_calculate_the_credit_if_oprocRokKredyt_is_null() throws IOException {

		HttpServletRequest request = mock(HttpServletRequest.class);
		HttpServletResponse response = mock(HttpServletResponse.class);
		PrintWriter writer = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(writer);
		HelloServlet servlet = new HelloServlet();
		when(request.getParameter("rodzajRatKredyt")).thenReturn("malejace");
		when(request.getParameter("liczbaRatKredyt")).thenReturn("0");
		when(request.getParameter("kwotaKredyt")).thenReturn("600");
		when(request.getParameter("oprocRokKredyt")).thenReturn("");
		when(request.getParameter("oplataStalaKredyt")).thenReturn("10");
		servlet.doPost(request, response);
		verify(response).sendRedirect("/");
	}

	@Test
	public void servlet_should_not_calculate_the_credit_if_rodzajRatKredyt_is_null() throws IOException {

		HttpServletRequest request = mock(HttpServletRequest.class);
		HttpServletResponse response = mock(HttpServletResponse.class);
		PrintWriter writer = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(writer);
		HelloServlet servlet = new HelloServlet();

		when(request.getParameter("rodzajRatKredyt")).thenReturn(null);
		when(request.getParameter("liczbaRatKredyt")).thenReturn("2");
		when(request.getParameter("kwotaKredyt")).thenReturn("600");
		when(request.getParameter("oprocRokKredyt")).thenReturn("3");
		when(request.getParameter("oplataStalaKredyt")).thenReturn("10");
		servlet.doPost(request, response);
		verify(response).sendRedirect("/");
	}

	@Test
	public void servlet_should_not_greet_the_user_if_the_rodzajRatKredyt_is_empty() throws IOException {
		HttpServletRequest request = mock(HttpServletRequest.class);
		HttpServletResponse response = mock(HttpServletResponse.class);
		PrintWriter writer = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(writer);
		HelloServlet servlet = new HelloServlet();

		when(request.getParameter("rodzajRatKredyt")).thenReturn("");
		when(request.getParameter("liczbaRatKredyt")).thenReturn("2");
		when(request.getParameter("kwotaKredyt")).thenReturn("600");
		when(request.getParameter("oprocRokKredyt")).thenReturn("3");
		when(request.getParameter("oplataStalaKredyt")).thenReturn("10");

		servlet.doPost(request, response);

		verify(response).sendRedirect("/");

	}

}
