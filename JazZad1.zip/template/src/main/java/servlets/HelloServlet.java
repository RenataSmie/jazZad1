package servlets;

import java.io.IOException;
import java.text.DecimalFormat;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/harmonogram")
public class HelloServlet extends HttpServlet {

	/**
	 * 
	 */

	double calkowitaKwotaRaty;
	double czescOdsetkowa;
	double czescKapitalowa;
	double kapitalNaKoniecOkresu;
	double rataBezOplatyStalej;
	double kapitalNaPoczatkuOkresu;

	private static final long serialVersionUID = 1L;
	DecimalFormat df = new DecimalFormat("#.##");

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String name = request.getParameter("name");
		response.setContentType("text/html");
		response.getWriter().println("<h1>Hello " + name + "</h1>");
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		double kwotaKredyt = 0;
		int liczbaRatKredyt = 0;
		double oprocRokKredyt = 0;
		double oplataStalaKredyt = 0;
		String rodzajRatKredyt = null;
		try {
			kwotaKredyt = Double.parseDouble(request.getParameter("kwotaKredyt"));
			liczbaRatKredyt = Integer.parseInt(request.getParameter("liczbaRatKredyt"));
			// double liczbaRatKredyt =
			// Double.parseDouble(request.getParameter("liczbaRatKredyt"));
			oprocRokKredyt = Double.parseDouble(request.getParameter("oprocRokKredyt"));
			oplataStalaKredyt = Double.parseDouble(request.getParameter("oplataStalaKredyt"));
			rodzajRatKredyt = request.getParameter("rodzajRatKredyt");
		} catch (NullPointerException | NumberFormatException e) {
			System.err.println("Caught NullPointerException: " + e.getMessage());
			response.sendRedirect("/");
			return;

		}

		if (Double.isNaN(kwotaKredyt) || liczbaRatKredyt == 0 || Double.isNaN(oprocRokKredyt)
				|| Double.isNaN(oplataStalaKredyt) || rodzajRatKredyt == null || rodzajRatKredyt.equals("")) {
			response.sendRedirect("/");
			return;
		}

		response.setContentType("text/html");
		response.getWriter().println("<h1>Harmonogram splat </h1>");
		response.getWriter().println("<table><tr>" + "<th>Nr raty </th>"
		// + "<th>Wysokosc kapitalu na poczatku okresu </th>"
				+ "<th>Kwota kapitalu </th>" + "<th>Kwota odsetek </th>" + "<th>Oplata stala </th>"
				+ "<th>Calkowita kwota raty </th>"
				// + "<td>Wysokosc kapitalu na koniec okresu </td>"
				+ "</tr><br>");

		kapitalNaPoczatkuOkresu = kwotaKredyt;

		if ("stale".equals(rodzajRatKredyt)) {

			rataBezOplatyStalej = kwotaKredyt
					/ ((1 - Math.pow(1 + (oprocRokKredyt / 100), -liczbaRatKredyt)) / (oprocRokKredyt / 100));

			for (int i = 1; i <= liczbaRatKredyt; i++) {

				calkowitaKwotaRaty = rataBezOplatyStalej + oplataStalaKredyt;
				czescOdsetkowa = (kapitalNaPoczatkuOkresu * (oprocRokKredyt / 100));
				czescKapitalowa = (rataBezOplatyStalej - (kapitalNaPoczatkuOkresu * (oprocRokKredyt / 100)));
				kapitalNaKoniecOkresu = kapitalNaPoczatkuOkresu
						- (rataBezOplatyStalej - (kapitalNaPoczatkuOkresu * (oprocRokKredyt / 100)));
				response.getWriter().println("<tr><td>" + i + "</td>"
				// + "<td>" + df.format(kapitalNaPoczatkuOkresu) + "</td>"
						+ "<td>" + df.format(czescKapitalowa) + "</td>" + "<td>" + df.format(czescOdsetkowa) + "</td>"
						+ "<td>" + df.format(oplataStalaKredyt) + "</td>" + "<td>" + df.format(calkowitaKwotaRaty)
						+ "</td>"
						// + "<td>" + kapitalNaKoniecOkresu + "</td>"
						+ "</tr>");

				kapitalNaPoczatkuOkresu = kapitalNaKoniecOkresu;

			}
			response.getWriter().println("</table>");

		} else if ("malejace".equals(rodzajRatKredyt)) {

			czescKapitalowa = kwotaKredyt / liczbaRatKredyt;

			for (int i = 1; i <= liczbaRatKredyt; i++) {

				czescOdsetkowa = (liczbaRatKredyt - i + 1) * czescKapitalowa * (oprocRokKredyt / 100);
				calkowitaKwotaRaty = czescKapitalowa + czescOdsetkowa + oplataStalaKredyt;

				response.getWriter().println("<tr><td>" + i + "</td>"
				// + "<td>" + df.format(kapitalNaPoczatkuOkresu) + "</td>"
						+ "<td>" + df.format(czescKapitalowa) + "</td>" + "<td>" + df.format(czescOdsetkowa) + "</td>"
						+ "<td>" + df.format(oplataStalaKredyt) + "</td>" + "<td>" + df.format(calkowitaKwotaRaty)
						+ "</td>"
						// + "<td>" + kapitalNaKoniecOkresu + "</td>"
						+ "</tr>");
			}

			kapitalNaPoczatkuOkresu = kapitalNaPoczatkuOkresu - czescKapitalowa;
			response.getWriter().println("</table>");
		}

	}
}
